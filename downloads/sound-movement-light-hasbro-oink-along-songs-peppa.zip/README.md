# Switch Adapted Hasbro Oink Along Songs Peppa Plush
The Switch Adapted Peppa Pig Toy is a switch adapted plush Peppa Pig toy that makes noises and sings songs when the switch is activated. 

<p align="center">
 <img width="500" src="https://github.com/makersmakingchange/switch-adapted-peppa-pig-toy/blob/7c03538f8719ce9216d22b65e7ad89e69738c145/Photos/switch-adapted-peppa-pig-toy.jpg" alt="Picture of a switch adapted plush Peppa Pig toy.">
</p>

## More info at
- [Makers Making Change Project Page](https://makersmakingchange.com/project/switch-adapted-peppa-pig-toy/)


## How to Obtain a Switch Adapted Hasbro Oink Along Songs Peppa Plush
### 1. Do it Yourself (DIY) or Do it Together (DIT)

This is an open-source assistive technology, so anyone is free to build it. All of the files and instructions required to build the Switch Adapted Peppa Pig Toy are contained within this repository. Refer to the Maker Checklist below.

### 2. Request a build of this device

If you would like to obtain a Switch Adapted Peppa Pig Toy, you may submit a build request through the [MMC Library Page](https://www.makersmakingchange.com/product/switch-adapted-hasbro-oinkalong-songs-peppa-plush/01tJR000000694UYAQ). The requestor is responsible for the cost of materials and any shipping.

### 3. How to build this device for someone else

If you have the skills and equipment to build this device, and would like to donate your time to adapt a toy for someone who needs it, visit the [MMC Maker Wanted](https://makersmakingchange.com/maker-wanted/) section.


## Getting Started

### 1. Read the Makers Checklist

The Makers Checklist contains a list of tasks to complete to build the device.

### 2. Order the Off-The-Shelf Components

The [Bill of Materials](/Documentation/Peppa_Pig_BOM_v1.0.xlsx) lists all of the parts and components required to build the Switch Adapted Peppa Pig Toy. The main switch component needs to be ordered online. The rest of the off-the-shelf components are also online or may be available in smaller quantities at your local hardware store or dollar store.

### 3. Assemble the Switch Adapted Peppa Pig Toy

Reference the [Assembly Guide](/Documentation/Peppa_Pig_Assembly_Guide_v1.0.pdf) for the tools and steps required to build each portion.

## Files
### Documentation
| Document             | Version | Link |
|----------------------|---------|------|
| Design Rationale     | 1.0     | [Peppa Pig Design Rationale](https://github.com/makersmakingchange/Adapted-Toys/blob/bc86300f3b0eae2811bf68a4ef74ecb4e4579407/Toy_Instructions/Available_Toys/Sound%2BMovement%2BLight-Up_Toys/Hasbro%20-%20Oink-Along%20Songs%20Peppa%20Toy/Peppa_Pig_Design_Rationale_v1.0.pdf)     |
| Maker Checklist      | 1.0     | [Peppa_Pig_Maker_Checklist](/Peppa_Pig_Maker_Checklist_v1.0.pdf)     |
| Bill of Materials    | 1.0     | [Peppa_Pig_Bill_of_Materials](/Peppa_Pig_BOM_v1.0.xlsx)     |
| Assembly Guide       | 1.0     | [Peppa Pig Assembly Guide](https://github.com/makersmakingchange/Adapted-Toys/blob/9d625e8b73419c6701886cfb9ad90c898146936d/Toy_Instructions/Available_Toys/Sound%2BMovement%2BLight-Up_Toys/Hasbro%20-%20Oink-Along%20Songs%20Peppa%20Toy/Peppa_Pig_Assembly_Guide_v1.0.pdf)     |
| User Guide           | 1.0     | [Peppa_Pig_User_Guide](/Peppa_Pig_User_Guide_v1.0.pdf)    |
| Changelog            | 1.0     | [Peppa_Pig_Changelog](/Peppa_Pig_Changelog_v1.0.pdf)     |


## Attribution
Modification method and documentation created by Neil Squire / Makers Making Change.



## License
Everything needed or used to design, make, test, or prepare the Switch Adapted Peppa Pig Toy is licensed under the CERN 2.0 Permissive license <https://ohwr.org/cern_ohl_p_v2.txt> (CERN-OHL-P) . 

Accompanying material such as instruction manuals, videos, and other copyrightable works that are useful but not necessary to design, make, test, or prepare the Switch Adapted Peppa Pig Toy are published under a Creative Commons Attribution-ShareAlike 4.0 license https://creativecommons.org/licenses/by-sa/4.0/ (CC BY-SA 4.0).


---
<!-- ABOUT MMC START -->
## About Makers Making Change
[<img src="https://raw.githubusercontent.com/makersmakingchange/makersmakingchange/main/img/mmc_logo.svg" width="500" alt="Makers Making Change Logo">](https://www.makersmakingchange.com/)

Makers Making Change is a program of [Neil Squire](https://www.neilsquire.ca/), a Canadian non-profit that uses technology, knowledge, and passion to empower people with disabilities.

Makers Making Change leverages the capacity of community based Makers, Disability Professionals and Volunteers to develop and deliver affordable Open Source Assistive Technologies.

 - Website: [www.MakersMakingChange.com](https://www.makersmakingchange.com/)
 - GitHub: [makersmakingchange](https://github.com/makersmakingchange)
 - Bluesky: [@makersmakingchange.bsky.social](https://bsky.app/profile/makersmakingchange.bsky.social)
 - Instagram: [@makersmakingchange](https://www.instagram.com/makersmakingchange)
 - Facebook: [makersmakechange](https://www.facebook.com/makersmakechange)
 - LinkedIn: [Neil Squire Society](https://www.linkedin.com/company/neil-squire-society/)
 - Thingiverse: [makersmakingchange](https://www.thingiverse.com/makersmakingchange/about)
 - Printables: [MakersMakingChange](https://www.printables.com/@MakersMakingChange)

### Contact Us
For technical questions, to get involved, or to share your experience we encourage you to [visit our website](https://www.makersmakingchange.com/) or [contact us](https://www.makersmakingchange.com/s/contact).
<!-- ABOUT MMC END -->
