---
# Fill in the value after each colon, on the SAME line as the field -
# don't press Enter partway through a value. Leave a field completely
# blank (nothing after the colon) if you don't have that info yet.
last_updated: 2026-08-21               # yyyy-mm-dd - date this file was last updated
toy_features:                # keep only the relevant lines below, delete the rest
  - Sound
  - Light
activation_type:            # keep only the relevant lines below, delete the rest
  - Single Press
requires_3d_printing: No    # Yes or No
adaptation_method:          # keep only the relevant lines below, delete the rest
  - Mono Jack + Wire
number_of_switches:         # keep only the relevant lines below, delete the rest
  - 2
hfth_collection_year: 2026       # e.g. 2026 - leave blank if never part of a HFTH collection
available_to_purchase: Yes  # Yes or No - is the toy still available to purchase?
toy_purchase_link: https://www.walmart.ca/en/ip/Fisher-Price-Laugh-Learn-Wake-Up-Learn-Coffee-Mug-Baby-Toddler-Toy-with-Music-Lights-Brown-Green/6000208718549    # adds a "Where to Buy This Toy" button if filled in
toy_purchase_link_alt: https://www.amazon.ca/Fisher-Price-Toddler-Coffee-Learning-Content/dp/B0CBQV2FBV/      # adds a 2nd purchase button if there's another link
general_notes: Moderate difficulty              # any general notes, e.g. "Uses lots of screws."
device_uid:                  # internal MMC use only - never shown on the site
name:                        # only fill in to OVERRIDE the auto name - else leave blank
category:                    # only fill in to OVERRIDE the auto category - else leave blank
link:                        # only fill in to OVERRIDE the auto GitHub link - else leave blank
battery_type: LR 44
battery_required: 3
battery_included:
---

Every child deserves to play. But for many kids with disabilities, toys can be hard to use independently, and commercially adapted versions can run upwards of $300. However, with a little bit of tinkering, we can switch-adapt toys and make them accessible for a fraction of the cost.

Annually, from September to December Makers Making Change hosts the [Hacking for the Holidays](https://www.makersmakingchange.com/hacking-for-the-holidays) campaign, where we engage volunteers — students, corporate partners, and other community members — in many build events across Canada to help us adapt and donate thousands of toys and switches to families and clinicians all over Canada.

Please note the information on this page is only accurate to when it was last updated.

If you are looking for more information on where to purchase the materials to adapt a toy, please visit the [Common Component and Tool page](https://makersmakingchange.github.io/Switch_Adapted_Toys/toy-components-and-tools/) on this resource.

<!--
  Everything above this line (outside the --- --- block at the top) is
  just for humans reading this file - it isn't read by the site build.
  This same text already shows automatically on every toy's page, so you
  don't need to copy/edit it per toy; it's here for context only.

  ONE IMPORTANT RULE for the fields inside the --- --- block above:
  keep every value on the SAME line as its field name. If a value
  wraps onto a second line by accident (e.g. a long name spilling onto
  a new line without quotes), that whole wrapped block gets silently
  read as one long piece of text - which can also swallow the field(s)
  that come right after it. If you ever need to double check a field
  looks right, open this file on GitHub and confirm nothing after a
  colon spills onto its own new line unless it's a "- " list item.
-->
